#!/bin/sh

autoreconf -f
